param([int]$Puerto, [switch]$VistaPrevia)
$ErrorActionPreference = 'Stop'
$nombres = 'core-1','core-2','dc-dist','r-sw1','r-sw2','s-dist','onos-1','onos-2','atomix-3','ldap-radius','dns-dhcp','recursos','ids','alumno'
if (-not $Puerto) {
    for ($i=0; $i -lt $nombres.Count; $i++) {
        Write-Host ('{0}  {1,-12}  192.168.0.{2}' -f (5800+$i),$nombres[$i],(10+$i))
    }
    $Puerto = [int](Read-Host 'Puerto de la VM que tienes abierta')
}
if ($Puerto -lt 5800 -or $Puerto -gt 5813) { throw 'Elige un puerto entre 5800 y 5813.' }
$nombre = $nombres[$Puerto-5800]
$ip = '192.168.0.{0}/24' -f ($Puerto-5790)
# Toda la linea queda a la vista; la persona en la consola decide cuando ejecutarla.
$linea = @(
    'ip link show dev ens3 >/dev/null'
    '! ip -o -4 addr show dev ens3 | grep -qw 10.20.12.7'
    'sudo netplan set ethernets.ens3.dhcp4=false'
    "sudo netplan set 'ethernets.ens3.addresses=[$ip]'"
    'sudo netplan set ethernets.ens3.dhcp6=false'
    'sudo netplan set ethernets.ens3.accept-ra=false'
    "sudo netplan set 'ethernets.ens3.link-local=[]'"
    'sudo netplan try'
    "sudo hostnamectl set-hostname $nombre"
    "sudo sed -i 's/^127[.]0[.]1[.]1[[:space:]].*/127.0.1.1 $nombre/' /etc/hosts"
    'hostname'
    'ip -br -4 addr show dev ens3'
) -join ' && '
Write-Host "`nDestino: $nombre    ens3: $ip    SSH: $Puerto"
Write-Host $linea
if ($VistaPrevia) { return }
Add-Type -AssemblyName System.Windows.Forms
Add-Type -TypeDefinition @'
using System;
using System.Runtime.InteropServices;
public static class VentanaVNRT {
    [DllImport("user32.dll")] public static extern IntPtr GetForegroundWindow();
    [DllImport("user32.dll")] public static extern uint GetWindowThreadProcessId(IntPtr h, out uint pid);
}
'@
function Esperar-Navegador {
Write-Host 'Tienes 7 segundos para hacer clic dentro de la consola de la VM.'
Start-Sleep -Seconds 7
$ventana = [VentanaVNRT]::GetForegroundWindow()
[uint32]$idNavegador = 0
[void][VentanaVNRT]::GetWindowThreadProcessId($ventana,[ref]$idNavegador)
$proceso = (Get-Process -Id $idNavegador).ProcessName
if ($proceso -notin 'chrome','msedge','firefox','brave','opera','vivaldi') {
    throw 'La ventana activa no es un navegador reconocido. No se escribio la linea.'
}
return $ventana
}
function Tecla([string]$valor) {
    if ([VentanaVNRT]::GetForegroundWindow() -ne $ventana) {
        throw 'Cambio la ventana activa; escritura detenida. Si estas en Vim, pulsa Esc y luego ZQ para salir.'
    }
    [System.Windows.Forms.SendKeys]::SendWait($valor)
    Start-Sleep -Milliseconds 35
}
function Escribir-EnVim([string]$texto) {
    foreach ($c in $texto.ToCharArray()) {
        if ($c -cmatch '[a-zA-Z0-9 ]') { Tecla ([string]$c) }
        else {
            # En modo insertar Vim interpreta Ctrl+V y tres cifras como un byte decimal.
            Tecla '^v'
            foreach ($n in ([int]$c).ToString('000').ToCharArray()) { Tecla ([string]$n) }
        }
    }
}
$archivo = 'vnrt' + $Puerto + ([guid]::NewGuid().ToString('N').Substring(0,5))
$muestra = '# /24 - = [ ] | &&'
Write-Host "Prueba esperada en Vim: $muestra"
[void](Read-Host 'Abre una linea VACIA del shell Ubuntu, sal de cualquier editor y pulsa Enter aqui')
$ventana = Esperar-Navegador
foreach ($c in "vi $archivo".ToCharArray()) { Tecla ([string]$c) }
Tecla '{ENTER}'
Start-Sleep -Milliseconds 1200
Tecla 'i'
Escribir-EnVim $muestra
Tecla '{ESC}'
Write-Host "Comprueba que aparece EXACTAMENTE: $muestra"
if ((Read-Host 'Escribe SI aqui si coincide; cualquier otra respuesta cancela') -cne 'SI') {
    Write-Host 'Cancelado. En Vim pulsa Esc y luego ZQ para salir sin guardar.'; return
}
$segunda = Esperar-Navegador
if ($segunda -ne $ventana) { throw 'Vuelve a la misma ventana del navegador.' }
Tecla 'o'
Tecla '^u'
Escribir-EnVim $linea
Tecla '{ESC}'
Write-Host "Revisa el comando en Vim. Para guardar y salir pulsa Shift+Z dos veces."
Write-Host "Luego escribe en Ubuntu (solo letras, numeros y espacio): bash $archivo"
